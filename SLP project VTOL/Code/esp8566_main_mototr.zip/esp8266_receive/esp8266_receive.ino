#include <sbus.h>

bfs::SbusRx sbus(&Serial, true);

void setup() {
  Serial.begin(100000, SERIAL_8E2);
  Serial.swap();  // moves RX to GPIO13, TX to GPIO15
  sbus.Begin();
}

void loop() {
  if (sbus.Read()) {
    bfs::SbusData data = sbus.data();
    Serial.println(data.ch[2]);  // NOTE: can't use Serial for debug anymore after swap
  }
}